# Café R2 — Free Deployment Guide (GitHub + Cloudflare Pages + Turnstile + Formspree)

This guide uses **only free tiers** — no paid domain required yet. Your site
will live at a free web address like `cafe-r2.pages.dev` until you're ready
to buy a real domain (at which point you just point it at the same
Cloudflare Pages project — nothing else changes).

Do these in order: **1) GitHub → 2) Cloudflare Pages → 3) Turnstile → 4) Formspree.**

---

## 1. Put the code on GitHub

1. Go to [github.com](https://github.com) and sign in (or create a free account).
2. Click the **+** icon top-right → **New repository**.
   - Name it e.g. `cafe-r2-website`
   - Keep it **Public** (required for free Cloudflare Pages builds) or Private — both work with Cloudflare Pages, Public is simplest.
   - Don't add a README/gitignore (we already have files) — click **Create repository**.
3. On the empty repo page, click **uploading an existing file**.
4. Drag in **everything inside the `site/` folder** from the zip (index.html, css/, js/, images/, robots.txt, sitemap.xml, README.md) — not the outer `site` folder itself, its *contents*.
5. Scroll down, click **Commit changes**.

That's it — your code is now on GitHub.

*(If you're comfortable with git on the command line instead, it's the usual `git init`, `git add .`, `git commit -m "first version"`, `git remote add origin <repo-url>`, `git push -u origin main`.)*

---

## 2. Host it free with Cloudflare Pages

1. Go to [dash.cloudflare.com](https://dash.cloudflare.com) and sign in / sign up (free).
2. In the left sidebar: **Workers & Pages** → **Create** → **Pages** tab → **Connect to Git**.
3. Authorize Cloudflare to access your GitHub account, then pick your `cafe-r2-website` repo.
4. Build settings:
   - **Framework preset:** None
   - **Build command:** *(leave blank)*
   - **Build output directory:** `/` (or `/site` if you uploaded the whole folder including the outer `site` directory — match whatever structure you pushed)
5. Click **Save and Deploy**. In under a minute you'll get a live URL like:
   `https://cafe-r2-website.pages.dev`
6. Every time you push a change to GitHub, Cloudflare Pages automatically redeploys. No manual re-upload needed again after this.

---

## 3. Set up Cloudflare Turnstile (spam protection on the contact form)

1. Still in the Cloudflare dashboard, go to **Turnstile** in the left sidebar.
2. Click **Add widget**.
   - **Name:** Cafe R2 Contact Form
   - **Domain:** enter your `*.pages.dev` address from Step 2 (e.g. `cafe-r2-website.pages.dev`) — you can add your real domain here too later, no need to remove the old one.
   - **Widget mode:** Managed (recommended)
3. Click **Create**. You'll now see a **Site Key** and a **Secret Key** — copy both somewhere safe.
4. Open `js/main.js` in your GitHub repo (click the file → pencil/edit icon), find:
   ```js
   TURNSTILE_SITE_KEY: "1x00000000000000000000AA",
   ```
   Replace the placeholder with your real **Site Key**, then commit the change. Cloudflare Pages will auto-redeploy.

Keep the **Secret Key** for the next step — never put it in the website's HTML/JS, it's only used on Formspree's side.

---

## 4. Set up Formspree (handles the actual email + verifies Turnstile)

1. Go to [formspree.io](https://formspree.io) and finish creating/verifying your account (you mentioned this is already in progress).
2. Once verified, click **New Form**. Name it "Café R2 Contact Form" and set the destination email (e.g. `cafer2juicebar@gmail.com`).
3. You'll get a form endpoint that looks like `https://formspree.io/f/abcdwxyz`. Copy it.
4. In your Formspree form's **Settings** tab, find the **CAPTCHA** section:
   - Enable CAPTCHA protection.
   - Choose **Cloudflare Turnstile**.
   - Paste the **Secret Key** you copied in Step 3.
   - Save.
5. Back in your GitHub repo, open `js/main.js` and update:
   ```js
   FORM_ENDPOINT: "https://formspree.io/f/REPLACE_WITH_YOUR_FORM_ID",
   ```
   with your real endpoint from step 3 above.
6. Also open `index.html`, find the `<form ... action="https://formspree.io/f/REPLACE_WITH_YOUR_FORM_ID" ...>` line near the contact section, and update it the same way (keeps the form working even if JavaScript is blocked).
7. Commit both changes — Cloudflare Pages redeploys automatically.
8. Test it: open your live `.pages.dev` site, fill in the contact form, and submit. You should get an email, and Formspree's dashboard will show the submission too.

---

## When you're ready for a real domain later

1. Buy the domain from any registrar (Namecheap, Cloudflare Registrar, etc.).
2. In Cloudflare Pages → your project → **Custom domains** → **Set up a custom domain** → follow the prompts (Cloudflare will handle the DNS if the domain is on Cloudflare, or give you records to add elsewhere).
3. Add the new domain to your Turnstile widget's **Allowed Domains** list (Step 3 above) — you don't need to remove the `.pages.dev` one.
4. Update the `caferz2.lk` placeholder in `index.html`'s SEO tags (see the main README.md) to your real domain.

That's the whole stack — GitHub for code, Cloudflare Pages for free hosting, Turnstile for spam protection, Formspree for the contact form — all on free tiers.

I'm happy to walk through any of these steps live with you, one at a time, whenever you're ready.
